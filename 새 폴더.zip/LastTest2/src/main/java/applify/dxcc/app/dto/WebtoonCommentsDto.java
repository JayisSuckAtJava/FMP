package applify.dxcc.app.dto;

public class WebtoonCommentsDto {

	int commentnum;
	String id;
	String comments;
	String writeDate;
	int rec;
	String articleNum;
}
