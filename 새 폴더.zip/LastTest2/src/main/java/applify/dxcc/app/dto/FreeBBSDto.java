package applify.dxcc.app.dto;

public class FreeBBSDto {
	int articleNum;
	String title;
	String id;
	String content;
	String writeDate;
	int views;
	int rec;
	int category;
}
