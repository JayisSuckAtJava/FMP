package applify.dxcc.app.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DxccloginDto {
	
	int clientNumb;
	String id;
	String password;
	String signinDate;
	int	drama;
	int	school;
	int	omnibus;
	int	horo;
	int	gag;
	int	life;
	int romance;
	int sport;
	int lgbt;
	String email;
	String nick;
	
}
